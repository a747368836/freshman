package com.mredrock.cyxbs.freshman.CQUPTAppearance;

/**
 * Created by 郝书逸 on 2018/8/15.
 */

public interface ICQUPTAppearanceView {
    void showError(String errorMessage);
    void show(CQUPTAppearance_Bean_10 bean);
}
