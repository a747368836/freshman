package com.mredrock.cyxbs.freshman.CampusStrategy.DataReveal.BGPercent;

import java.util.List;

public interface IBGView {
    void showList(BGBean bean);

    void showError(String errorMessage);
}
