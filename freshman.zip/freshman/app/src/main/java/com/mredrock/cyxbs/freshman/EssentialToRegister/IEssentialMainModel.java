package com.mredrock.cyxbs.freshman.EssentialToRegister;

import java.util.List;

public interface IEssentialMainModel {
    void RequestData(String url,EssentialOnRequesListner onRequesListner);




}
