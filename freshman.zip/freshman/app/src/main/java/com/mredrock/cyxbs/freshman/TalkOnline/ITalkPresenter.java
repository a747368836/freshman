package com.mredrock.cyxbs.freshman.TalkOnline;


public interface ITalkPresenter {
    void loadList(String url,String type,String content,TalkRecyAdapter adapter);
}
