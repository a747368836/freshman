package com.mredrock.cyxbs.freshman.CampusStrategy.DataReveal.BGPercent;

public class BGBean {

    /**
     * female_amount : 296
     * male_amount : 1379
     */

    private int female_amount;
    private int male_amount;

    public int getFemale_amount() {
        return female_amount;
    }

    public void setFemale_amount(int female_amount) {
        this.female_amount = female_amount;
    }

    public int getMale_amount() {
        return male_amount;
    }

    public void setMale_amount(int male_amount) {
        this.male_amount = male_amount;
    }
}
