package com.mredrock.cyxbs.freshman.CampusStrategy.DataReveal.BGPercent;

public interface IBGPresenter {
    void loadList(String url,String name);
}
