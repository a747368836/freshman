package com.mredrock.cyxbs.freshman.CampusStrategy.DataReveal;

import java.util.List;

public class DataRevealBean {

    private List<String> name;

    public List<String> getName() {
        return name;
    }

    public void setName(List<String> name) {
        this.name = name;
    }
}
