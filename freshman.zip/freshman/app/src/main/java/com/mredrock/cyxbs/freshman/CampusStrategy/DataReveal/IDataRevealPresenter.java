package com.mredrock.cyxbs.freshman.CampusStrategy.DataReveal;

import com.mredrock.cyxbs.freshman.CampusStrategy.BBE.BBERecyAdapter;
import com.scwang.smartrefresh.layout.api.RefreshLayout;

public interface IDataRevealPresenter {


    void loadList(String url);



}
