package com.mredrock.cyxbs.freshman.Tools.Album;

import android.content.Context;
import android.widget.ImageView;

/**
 * Created by 郝书逸 on 2018/8/10.
 */

public interface IAlbumPresenter {
    void setImage(String url, ImageView imageView, Context context);

}
