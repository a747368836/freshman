package com.mredrock.cyxbs.freshman.CampusStrategy.DataReveal.DiffcultColumn;

public interface IDiffPresenter {
    void loadList(String url,String name);
}
