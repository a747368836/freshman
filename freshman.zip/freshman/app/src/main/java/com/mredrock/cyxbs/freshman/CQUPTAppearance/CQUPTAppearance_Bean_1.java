package com.mredrock.cyxbs.freshman.CQUPTAppearance;

import java.util.List;

/**
 * Created by 郝书逸 on 2018/8/11.
 */

public class CQUPTAppearance_Bean_1 {
    private String amount;
    private List<String> name;
    private String index;

    public void setAmount(String amount) {
        this.amount = amount;
    }

    public void setName(List<String> name) {
        this.name = name;
    }

    public void setIndex(String index) {
        this.index = index;
    }

    public String getAmount() {

        return amount;
    }

    public List<String> getName() {
        return name;
    }

    public String getIndex() {
        return index;
    }
}
